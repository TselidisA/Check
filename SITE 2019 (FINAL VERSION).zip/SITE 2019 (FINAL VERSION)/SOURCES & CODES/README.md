# NEW SITE

Create new site and up-date rework it with as team in github platform.

## Site
We made this project for creat , design , up-date weakly our site.


## Coding
We use basic **HTML** , **CSS** , **JAVASCRIPT** coding for this project.

You can find the [tutorials](https://www.w3schools.com/) here.


## Updating 
Our goal is to end up this project with a site which works correctly.

So we will make new versions of this site for fix old bugs, add extra filled , use extra coding etc.
